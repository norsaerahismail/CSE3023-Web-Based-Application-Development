# 🌙 MoonBae: Period Tracker
**CSE3023 Web-Based Application Development | FSKM, UMT**
**Semester II 2025/2026**

---

## Ahli Kumpulan
| Nama | No. Matrik | Modul |
|---|---|---|
| Nor Saerah Binti Ismail (Ketua) | S75325 | Menstrual Tracking |
| Nor Ain Natasya Binti Kamarulzaman | S76002 | Prediction & Notification |
| Siti Zulaikha Binti Shamsuri | S75309 | User Management |

---

## Stack Teknologi
- **Frontend:** JSP + CSS (custom) + Font Awesome
- **Backend:** Java Servlets (Java EE)
- **Database:** MySQL 8.x
- **Server:** Apache Tomcat 9.x
- **IDE:** NetBeans 12+

---

## Prasyarat Persekitaran
1. **JDK 11+** dipasang dan dikonfigurasi
2. **NetBeans IDE 12+** (dengan plugin Java EE)
3. **Apache Tomcat 9.x** (tambah dalam NetBeans > Tools > Servers)
4. **MySQL Server 8.x** berjalan pada port 3306
5. **mysql-connector-java-8.x.jar** - tambah ke Libraries projek

---

## Panduan Pemasangan

### Langkah 1: Sediakan Database
```sql
-- Jalankan dalam MySQL Workbench atau terminal MySQL
source /path/to/MoonBae/sql/moonbae_db.sql;
```

### Langkah 2: Konfigurasi Sambungan DB
Buka fail: `src/java/com/moonbae/util/DatabaseConnection.java`

Tukar nilai berikut mengikut persekitaran anda:
```java
private static final String DB_USER = "root";    // Username MySQL anda
private static final String DB_PASS = "";         // Password MySQL anda
```

### Langkah 3: Bina Projek NetBeans
1. Buka NetBeans → File → Open Project → Pilih folder MoonBae
2. Klik kanan projek → Properties → Libraries
3. Klik "Add JAR/Folder" → Pilih `mysql-connector-java-8.x.jar`
4. Klik kanan projek → Clean and Build

### Langkah 4: Deploy ke Tomcat
1. Klik kanan projek → Run
2. Pilih Tomcat 9.x sebagai server
3. Buka browser: `http://localhost:8080/MoonBae`

---

## Akaun Ujian (Sudah Ada dalam Database)
| Email | Password |
|---|---|
| saerah@email.com | password123 |
| natasya@email.com | password123 |

---

## Struktur Projek
```
MoonBae/
├── sql/
│   └── moonbae_db.sql              ← Skrip database
├── src/java/com/moonbae/
│   ├── model/
│   │   ├── User.java
│   │   ├── Profile.java
│   │   ├── PeriodLog.java
│   │   └── Prediction.java
│   ├── dao/
│   │   ├── UserDAO.java
│   │   ├── PeriodLogDAO.java
│   │   └── PredictionDAO.java
│   ├── servlet/
│   │   ├── AuthServlet.java        ← /auth
│   │   ├── DashboardServlet.java   ← /dashboard
│   │   └── TrackingServlet.java    ← /tracking, /history, /delete-log
│   └── util/
│       ├── DatabaseConnection.java
│       └── PasswordUtil.java
└── web/
    ├── WEB-INF/
    │   └── web.xml
    ├── login.jsp
    ├── dashboard.jsp
    ├── add_record.jsp
    └── history.jsp
```

---

## Algoritma Ramalan Kitaran
```
predictedStartDate = tarikh_mula_terkini + purata_selang_kitaran

Di mana:
  purata_selang_kitaran = purata(selang_antara_3_rekod_terkini)
  Jika data kurang dari 2 rekod → guna cycleLength dari profil (lalai: 28 hari)
```

## Sistem Peringatan
- Peringatan AKTIF jika tarikh ramalan dalam masa **7 hari** ke hadapan
- Mesej khas apabila haid dijangka pada **hari ini**
- Banner peringatan dipaparkan pada dashboard

---

## URL Mapping
| URL | Controller | Keterangan |
|---|---|---|
| `/login.jsp` | – | Halaman log masuk / daftar |
| `/auth` (POST action=login) | AuthServlet | Proses log masuk |
| `/auth` (POST action=register) | AuthServlet | Proses pendaftaran |
| `/auth?action=logout` | AuthServlet | Log keluar |
| `/dashboard` | DashboardServlet | Paparan utama |
| `/tracking` (GET) | TrackingServlet | Borang tambah rekod |
| `/tracking` (POST) | TrackingServlet | Simpan rekod baru |
| `/history` | TrackingServlet | Sejarah semua rekod |
| `/delete-log?id=X` | TrackingServlet | Padam rekod |
