package com.moonbae.servlet;

import com.moonbae.dao.PeriodLogDAO;
import com.moonbae.model.PeriodLog;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet; // ✨ DITAMBAH UNTUK ROUTING SERVLET
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Controller: HistoryServlet
 * Menguruskan paparan halaman sejarah kitaran haid pengguna.
 * ✨ DIBAIKI: Meletakkan semula pengisytiharan WebServlet supaya Tomcat kenal jalan /history.
 */
@WebServlet(name = "HistoryServlet", urlPatterns = {"/history"})
public class HistoryServlet extends HttpServlet {

    private final PeriodLogDAO logDAO = new PeriodLogDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userID = (int) session.getAttribute("userID");
        com.moonbae.dao.UserDAO userDAO = new com.moonbae.dao.UserDAO();
        request.setAttribute("profile", userDAO.getProfileByUserID(userID));
        
        // 1. Ambil semua data log dari database untuk user ni
        List<PeriodLog> allLogs = logDAO.getLogsByUserID(userID);
        
        // Safety check: Kalau null, bagi list kosong biar tak crash
        if (allLogs == null) {
            allLogs = new ArrayList<>();
        }

        // 2. Simpan dalam request attribute untuk dibaca oleh history.jsp
        request.setAttribute("allLogs", allLogs);

        // 3. Forward ke view history.jsp
        request.getRequestDispatcher("/history.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public String getServletInfo() {
        return "History Controller";
    }
}