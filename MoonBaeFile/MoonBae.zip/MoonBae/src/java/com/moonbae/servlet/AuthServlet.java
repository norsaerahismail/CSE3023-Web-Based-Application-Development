package com.moonbae.servlet;

import com.moonbae.dao.UserDAO;
import com.moonbae.model.User;
import com.moonbae.model.Profile;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 * Controller: AuthServlet
 * Mengendalikan pendaftaran, login, pengurusan sesi, muat naik imej fail explorer, dan kemaskini profil.
 */
@WebServlet(name = "AuthServlet", urlPatterns = {"/auth", "/profile"})
// ✨ DIBAIKI: Ditambah MultipartConfig untuk membolehkan Servlet membaca muat naik fail komputer
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class AuthServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("logout".equals(action)) {
            request.getSession().invalidate();
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        } else {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        // ── 1. KEMASKINI PROFIL & DP FAIL EXPLORER ──
        if ("/profile".equals(path)) {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("userID") == null) {
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }

            int userID = (int) session.getAttribute("userID");
            String name = request.getParameter("name");
            int cycleLength = Integer.parseInt(request.getParameter("cycleLength"));
            String birthDateStr = request.getParameter("birthDate");

            // Ambil nama file sedia ada dari pangkalan data sebagai back-up lalai
            Profile currentProfile = userDAO.getProfileByUserID(userID);
            String avatarFileName = (currentProfile != null) ? currentProfile.getAvatar() : "avatar1.png";

            // Proses pemprosesan fail daripada File Explorer komputer
            Part filePart = request.getPart("avatarFile");
            if (filePart != null && filePart.getSize() > 0) {
                String submittedFileName = filePart.getSubmittedFileName();
                // Bina nama fail unik menggunakan userID bagi mengelakkan pertindihan
                String extension = submittedFileName.substring(submittedFileName.lastIndexOf("."));
                avatarFileName = "user_" + userID + "_dp" + extension;

                // Cipta folder simpanan dinamik bernama 'uploads' di dalam server Apache Tomcat
                String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdir();
                }

                // Simpan fail fizikal tersebut ke dalam storage server
                filePart.write(uploadPath + File.separator + avatarFileName);
            }

            // Jalankan kemaskini nama, kitaran, dan nama file avatar baharu
            boolean success = userDAO.updateProfileData(userID, name, cycleLength, avatarFileName);
            
            // ✨ Tambahan: Kemaskini tarikh lahir sekali ke dalam database menggunakan entiti asal
            if (success && currentProfile != null) {
                currentProfile.setName(name);
                currentProfile.setCycleLength(cycleLength);
                currentProfile.setAvatar(avatarFileName);
                if (birthDateStr != null && !birthDateStr.isEmpty()) {
                    currentProfile.setBirthDate(Date.valueOf(birthDateStr));
                }
                userDAO.updateProfile(currentProfile); 
            }

            if (success) {
                User user = (User) session.getAttribute("currentUser");
                if (user != null) {
                    user.setName(name);
                    user.setCycleLength(cycleLength);
                }
                response.sendRedirect(request.getContextPath() + "/dashboard?success=profile");
            } else {
                response.sendRedirect(request.getContextPath() + "/dashboard?error=profile");
            }
            return;
        }

        // ── 2. PROSES LOG MASUK & PENDAFTARAN ASAL ──
        String action = request.getParameter("action");
        if ("register".equals(action)) {
            String name = request.getParameter("name");
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");

            if (password == null || password.length() < 6) {
                request.setAttribute("regError", "Pendaftaran gagal! Kata laluan mestilah sekurang-kurangnya 6 aksara.");
                request.setAttribute("activeTab", "register");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }

            if (!password.equals(confirmPassword)) {
                request.setAttribute("regError", "Pendaftaran gagal! Kata laluan dan sahkan kata laluan tidak sepadan.");
                request.setAttribute("activeTab", "register");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }

            int newUserID = userDAO.registerUser(username, email, password, name);

            if (newUserID != -1) {
                request.setAttribute("success", "Pendaftaran berjaya! Sila log masuk.");
                request.setAttribute("activeTab", "login");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            } else {
                request.setAttribute("regError", "Pendaftaran gagal. Nama pengguna atau e-mel mungkin sudah wujud.");
                request.setAttribute("activeTab", "register");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
            
        } else if ("login".equals(action)) {
            String usernameOrEmail = request.getParameter("usernameOrEmail");
            String password = request.getParameter("password");

            User user = userDAO.loginUser(usernameOrEmail, password);
            
            if (user != null) {
                HttpSession session = request.getSession(true);
                session.setAttribute("userID", user.getUserID());
                session.setAttribute("username", user.getUsername());
                session.setAttribute("currentUser", user);
                
                response.sendRedirect(request.getContextPath() + "/dashboard");
                return;
            } else {
                request.setAttribute("error", "E-mel, Nama Pengguna atau kata laluan salah.");
                request.setAttribute("activeTab", "login");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        }
    }
}