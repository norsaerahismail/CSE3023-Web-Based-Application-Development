package com.moonbae.servlet;

import com.moonbae.dao.PeriodLogDAO;
import com.moonbae.dao.PredictionDAO;
import com.moonbae.dao.UserDAO;
import com.moonbae.model.PeriodLog;
import com.moonbae.model.Prediction;
import com.moonbae.model.Profile;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * Controller: TrackingServlet
 * Mengendalikan pendaftaran rekod haid baru, operasi padam, dan kemaskini rekod.
 * ✨ DIBAIKI: Membuang terus pautan "/history" dari urlPatterns supaya tidak bertembung dengan HistoryServlet.
 */
@WebServlet(name = "TrackingServlet", urlPatterns = {"/tracking", "/delete-log", "/edit-log"})
public class TrackingServlet extends HttpServlet {

    private final PeriodLogDAO  periodLogDAO  = new PeriodLogDAO();
    private final PredictionDAO predictionDAO = new PredictionDAO();
    private final UserDAO       userDAO       = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userID = (int) session.getAttribute("userID");
        request.setAttribute("profile", userDAO.getProfileByUserID(userID));
        String path = request.getServletPath();

        if ("/delete-log".equals(path)) {
            String dataIDStr = request.getParameter("id");
            if (dataIDStr != null) {
                try {
                    int dataID = Integer.parseInt(dataIDStr);
                    periodLogDAO.deleteLog(dataID, userID);
                } catch (NumberFormatException e) {
                    // ID tidak sah
                }
            }
            response.sendRedirect(request.getContextPath() + "/history");
        } else {
            // Paparan borang tambah rekod (/tracking)
            request.getRequestDispatcher("/add_record.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userID = (int) session.getAttribute("userID");
        String path = request.getServletPath();

        // ── 1. LOGIK KEMASKINI REKOD ──
        if ("/edit-log".equals(path)) {
            try {
                int dataID = Integer.parseInt(request.getParameter("dataID"));
                String startDateStr = request.getParameter("startDate");
                String endDateStr = request.getParameter("endDate");
                String bloodFlow = request.getParameter("bloodFlow");
                String notes = request.getParameter("notes");

                List<PeriodLog> currentLogs = periodLogDAO.getLogsByUserID(userID);
                String existingSymptoms = "";
                for(PeriodLog pl : currentLogs) {
                    if(pl.getDataID() == dataID) {
                        existingSymptoms = pl.getSymptoms();
                        break;
                    }
                }

                PeriodLog updatedLog = new PeriodLog();
                updatedLog.setDataID(dataID);
                updatedLog.setUserID(userID);
                updatedLog.setStartDate(Date.valueOf(startDateStr));
                updatedLog.setEndDate(Date.valueOf(endDateStr));
                updatedLog.setBloodFlowType(bloodFlow);
                updatedLog.setSymptoms(existingSymptoms);
                updatedLog.setNotes(notes);

                boolean updated = periodLogDAO.updateLog(updatedLog);
                if (updated) {
                    generateAndSavePrediction(userID);
                }
            } catch (Exception e) {
                System.err.println("[TrackingServlet] Ralat kemaskini: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/history");
            return;
        }

        // ── 2. LOGIK ASAL: SIMPAN REKOD BARU (/tracking) ──
        String startDateStr   = request.getParameter("startDate");
        String endDateStr     = request.getParameter("endDate");
        String bloodFlowType  = request.getParameter("bloodFlowType");
        String[] symptomsArr  = request.getParameterValues("symptoms");
        String notes          = request.getParameter("notes");

        if (startDateStr == null || startDateStr.isEmpty()) {
            request.setAttribute("error", "Tarikh mula diperlukan.");
            request.getRequestDispatcher("/add_record.jsp").forward(request, response);
            return;
        }

        PeriodLog log = new PeriodLog();
        log.setUserID(userID);
        log.setStartDate(Date.valueOf(startDateStr));

        if (endDateStr != null && !endDateStr.isEmpty()) {
            Date endDate = Date.valueOf(endDateStr);
            if (endDate.before(log.getStartDate())) {
                request.setAttribute("error", "Tarikh tamat tidak boleh lebih awal dari tarikh mula.");
                request.getRequestDispatcher("/add_record.jsp").forward(request, response);
                return;
            }
            log.setEndDate(endDate);
        }

        log.setBloodFlowType((bloodFlowType != null && !bloodFlowType.isEmpty()) ? bloodFlowType : "Medium");

        if (symptomsArr != null && symptomsArr.length > 0) {
            log.setSymptoms(String.join(",", symptomsArr));
        }

        log.setNotes((notes != null && !notes.isEmpty()) ? notes : null);

        boolean saved = periodLogDAO.insertLog(log);

        if (saved) {
            generateAndSavePrediction(userID);
            request.setAttribute("success", "Rekod haid berjaya disimpan!");
        } else {
            request.setAttribute("error", "Gagal menyimpan rekod. Sila cuba lagi.");
        }

        request.getRequestDispatcher("/add_record.jsp").forward(request, response);
    }

    private void generateAndSavePrediction(int userID) {
        PeriodLog latestLog = periodLogDAO.getLatestLog(userID);
        if (latestLog == null) return;

        Profile profile = userDAO.getProfileByUserID(userID);
        int cycleLength = (profile != null) ? profile.getCycleLength() : 28;

        double avgInterval = periodLogDAO.getAverageCycleInterval(userID);
        int predictedInterval = (avgInterval > 0) ? (int) Math.round(avgInterval) : cycleLength;

        long predictedStartMillis = latestLog.getStartDate().getTime() + (long) predictedInterval * 24 * 60 * 60 * 1000;
        Date predictedStart = new Date(predictedStartMillis);

        int estimatedDuration = 5;
        if (latestLog.getEndDate() != null) {
            estimatedDuration = latestLog.getDuration();
        }
        Date predictedEnd = new Date(predictedStartMillis + (long)(estimatedDuration - 1) * 24 * 60 * 60 * 1000);

        Prediction prediction = new Prediction(userID, predictedStart, predictedEnd);
        predictionDAO.savePrediction(prediction);
    }
}