package com.moonbae.servlet;

import com.moonbae.dao.PeriodLogDAO;
import com.moonbae.dao.PredictionDAO;
import com.moonbae.dao.UserDAO;
import com.moonbae.model.PeriodLog;
import com.moonbae.model.Prediction;
import com.moonbae.model.Profile;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * Controller: DashboardServlet
 * Mengendalikan paparan utama (dashboard) pengguna dengan sokongan penukaran bulan kalendar
 * dan logik peringatan (reminder) interaktif serta sokongan DP avatar.
 */
@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    private final UserDAO       userDAO       = new UserDAO();
    private final PeriodLogDAO  periodLogDAO  = new PeriodLogDAO();
    private final PredictionDAO predictionDAO = new PredictionDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ── Semak Sesi: Pengguna mesti log masuk ─────────────
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userID = (int) session.getAttribute("userID");

        // ── Menguruskan Parameter Penukaran Bulan ───────────
        LocalDate realToday = LocalDate.now();
        String paramYear = request.getParameter("year");
        String paramMonth = request.getParameter("month");

        // Jika ada parameter, guna bulan tersebut. Jika tidak, lalai ke bulan semasa.
        int displayYear = (paramYear != null) ? Integer.parseInt(paramYear) : realToday.getYear();
        int displayMonth = (paramMonth != null) ? Integer.parseInt(paramMonth) : realToday.getMonthValue();

        // ── Ambil data yang diperlukan ────────────────────────

        // 1. Profil pengguna (untuk cycleLength dan string fail avatar DP)
        Profile profile = userDAO.getProfileByUserID(userID);
        request.setAttribute("profile", profile);
        
        // ✨ Menghantar data nama fail gambar profil semasa ke halaman JSP dashboard (Modul Ika)
        String currentAvatar = (profile != null && profile.getAvatar() != null) ? profile.getAvatar() : "avatar1.png";
        request.setAttribute("currentAvatar", currentAvatar);

        // 2. 3 rekod haid terkini untuk paparan ringkas
        List<PeriodLog> recentLogs = periodLogDAO.getLogsByUserID(userID);
        List<PeriodLog> top3 = recentLogs.size() > 3 ? recentLogs.subList(0, 3) : recentLogs;
        request.setAttribute("recentLogs", top3);

        // 3. Rekod haid mengikut bulan paparan pilihan pengguna (Dinamik)
        List<PeriodLog> monthLogs = periodLogDAO.getLogsByMonth(userID, displayYear, displayMonth);
        request.setAttribute("monthLogs", monthLogs);
        
        // Atribut untuk penjejak kalendar
        request.setAttribute("currentYear", displayYear);
        request.setAttribute("currentMonth", displayMonth);
        
        // Simpan info bulan sebenar (real-time) untuk kegunaan butang 'auto-reset'
        request.setAttribute("realYear", realToday.getYear());
        request.setAttribute("realMonth", realToday.getMonthValue());
        
        // Tandakan hari ini HANYA jika pengguna melihat bulan semasa yang betul
        if (displayYear == realToday.getYear() && displayMonth == realToday.getMonthValue()) {
            request.setAttribute("today", realToday.getDayOfMonth());
        } else {
            request.setAttribute("today", -1);
        }
        request.setAttribute("todayFull", realToday.toString());

        // 4. Ramalan terkini
        Prediction prediction = predictionDAO.getLatestPrediction(userID);
        request.setAttribute("prediction", prediction);

        // 5. Kiraan hari semasa dalam kitaran (Current Cycle Day)
        PeriodLog latestLog = periodLogDAO.getLatestLog(userID);
        if (latestLog != null) {
            long diffMillis = System.currentTimeMillis() - latestLog.getStartDate().getTime();
            int currentCycleDay = (int)(diffMillis / (1000 * 60 * 60 * 24)) + 1;
            request.setAttribute("currentCycleDay", currentCycleDay);
            request.setAttribute("latestLog", latestLog);
            
            int cycleLen = (profile != null) ? profile.getCycleLength() : 28;
            int progress = Math.min((currentCycleDay * 100) / cycleLen, 100);
            request.setAttribute("cycleProgress", progress);
        }

        // 6. ✨ LOGIK KEMASKINI REMINDER (Versi Selamat - Kalis Ralat NullPointerException)
        String reminder = null;
        // Memastikan objek prediction dan tarikh jangkaan di dalamnya wujud (tidak null) sebelum membaca baki hari
        if (prediction != null && prediction.getPredictedStartDate() != null) {
            int days = prediction.getDaysUntilPeriod();
            
            if (days == 0) {
                reminder = "🚨 Hari Penting! Kitaran haid anda dijangka bermula HARI INI. Pastikan tuala wanita sudah sedia di dalam beg anda!";
            } else if (days > 0 && days <= 3) {
                reminder = "⚠️ Persediaan Awal: Kitaran haid anda dijangka bermula dalam masa " + days + " hari lagi. Jaga pemakanan dan dapatkan rehat secukupnya.";
            } else if (days > 3) {
                // Menghasilkan mesej dinamik walaupun baki hari kitaran haid masih lama
                reminder = "🌸 Status Kitaran: Anda mempunyai " + days + " hari lagi sebelum kitaran haid seterusnya bermula. Kekalkan gaya hidup sihat!";
            } else {
                reminder = "📢 Makluman: Tarikh jangkaan haid anda telah melepasi tempoh ramalan kitaran biasa.";
            }
        } else {
            // Mesej alternatif yang selamat jika tiada rekod langsung ditemui dalam database
            reminder = "👋 Selamat Datang ke MoonBae! Sila tambah rekod haid pertama anda di menu +Add Record untuk membolehkan sistem menjana kitaran ramalan.";
        }
        request.setAttribute("activeReminder", reminder);

        // 7. Pengiraan hari pertama bagi susun atur grid kalendar bulan pilihan
        LocalDate firstDay = LocalDate.of(displayYear, displayMonth, 1);
        request.setAttribute("firstDayOfWeek", firstDay.getDayOfWeek().getValue() % 7); // 0=Ahad
        request.setAttribute("daysInMonth", firstDay.lengthOfMonth());

        // 8. Nama bulan
        String[] monthNames = {"", "Januari","Februari","Mac","April","Mei","Jun",
                               "Julai","Ogos","September","Oktober","November","Disember"};
        request.setAttribute("monthName", monthNames[displayMonth]);

        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
}