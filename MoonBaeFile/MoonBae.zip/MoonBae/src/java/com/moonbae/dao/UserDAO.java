package com.moonbae.dao;

import com.moonbae.model.Profile;
import com.moonbae.model.User;
import com.moonbae.util.DatabaseConnection;
import java.sql.*;

/**
 * DAO: UserDAO
 * Menguruskan operasi CRUD bagi jadual 'users' dan 'profiles' menggunakan Hashing Terus MySQL.
 */
public class UserDAO {

    // ══════════════════════════════════════════════════════════
    // OPERASI: USER
    // ══════════════════════════════════════════════════════════

    /**
     * Daftar pengguna baru - Kata laluan di-hash terus di dalam MySQL menggunakan SHA2(?, 256)
     */
    public int registerUser(String username, String email, String password, String name) {
        // ✨ Guna fungsi SHA2(?, 256) milik MySQL secara langsung
        String sqlUser    = "INSERT INTO users (username, email, password) VALUES (?, ?, SHA2(?, 256))";
        String sqlProfile = "INSERT INTO profiles (userID, name, cycleLength) VALUES (?, ?, 28)";
        Connection conn   = null;

        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            try (PreparedStatement psUser = conn.prepareStatement(sqlUser, Statement.RETURN_GENERATED_KEYS)) {
                psUser.setString(1, username);
                psUser.setString(2, email);
                psUser.setString(3, password); // Teks biasa, MySQL akan tolong hash-kan
                psUser.executeUpdate();

                ResultSet rs = psUser.getGeneratedKeys();
                if (rs.next()) {
                    int newUserID = rs.getInt(1);

                    try (PreparedStatement psProfile = conn.prepareStatement(sqlProfile)) {
                        psProfile.setInt(1, newUserID);
                        psProfile.setString(2, name);
                        psProfile.executeUpdate();
                    }

                    conn.commit();
                    return newUserID;
                }
            }
            conn.rollback();
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal mendaftar pengguna: " + e.getMessage());
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { /* abaikan */ }
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException e) { /* abaikan */ }
        }
        return -1;
    }

    /**
     * ✨ LOG MASUK KALIS RALAT: Menyemak kesepaduan input menggunakan fungsi SHA2 MySQL terus!
     */
    public User loginUser(String usernameOrEmail, String password) {
        // ✨ Menyemak kata laluan dengan menukarkan input password kepada SHA2(?, 256) di sebelah database
        String sql = "SELECT userID, username, email FROM users WHERE (email = ? OR username = ?) AND password = SHA2(?, 256)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usernameOrEmail);
            ps.setString(2, usernameOrEmail);
            ps.setString(3, password); // Hantar teks biasa, MySQL akan bandingkan hasil hash dia
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserID(rs.getInt("userID"));
                    user.setUsername(rs.getString("username"));
                    user.setEmail(rs.getString("email"));
                    return user;
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal log masuk: " + e.getMessage());
        }
        return null;
    }

    public boolean emailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal semak email: " + e.getMessage());
        }
        return false;
    }

    public boolean usernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal semak username: " + e.getMessage());
        }
        return false;
    }

    // ══════════════════════════════════════════════════════════
    // OPERASI: PROFILE
    // ══════════════════════════════════════════════════════════

    public Profile getProfileByUserID(int userID) {
        String sql = "SELECT * FROM profiles WHERE userID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userID);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Profile p = new Profile();
                    p.setProfileID(rs.getInt("profileID"));
                    p.setUserID(rs.getInt("userID"));
                    p.setName(rs.getString("name"));
                    p.setBirthDate(rs.getDate("birthDate"));
                    p.setCycleLength(rs.getInt("cycleLength"));
                    p.setAvatar(rs.getString("avatar")); 
                    return p;
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal dapatkan profil: " + e.getMessage());
        }
        return null;
    }

    public boolean updateProfile(Profile profile) {
        String sql = "UPDATE profiles SET name=?, birthDate=?, cycleLength=? WHERE userID=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, profile.getName());
            ps.setDate(2, profile.getBirthDate());
            ps.setInt(3, profile.getCycleLength());
            ps.setInt(4, profile.getUserID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal kemaskini profil: " + e.getMessage());
        }
        return false;
    }

    public boolean updateProfileData(int userID, String name, int cycleLength, String avatar) {
        String sql = "UPDATE profiles SET name = ?, cycleLength = ?, avatar = ? WHERE userID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, name);
            ps.setInt(2, cycleLength);
            ps.setString(3, avatar);
            ps.setInt(4, userID);
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Gagal kemaskini data avatar profil: " + e.getMessage());
            return false;
        }
    }
}