package com.moonbae.model;

/**
 * Model: User
 * Mewakili entiti pengguna dalam sistem MoonBae.
 */
public class User {
    private int    userID;
    private String username;
    private String email;
    private String password;
    private String name;         // ✨ Ditambah supaya session boleh simpan nama terus
    private int    cycleLength;  // ✨ Ditambah supaya session boleh simpan panjang kitaran

    // ── Constructor ─────────────────────────────────────────
    public User() {}

    public User(int userID, String username, String email) {
        this.userID   = userID;
        this.username = username;
        this.email    = email;
    }

    // ── Getters & Setters ────────────────────────────────────
    public int    getUserID()   { return userID; }
    public void   setUserID(int userID)     { this.userID = userID; }

    public String getUsername() { return username; }
    public void   setUsername(String username) { this.username = username; }

    public String getEmail()    { return email; }
    public void   setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void   setPassword(String password) { this.password = password; }

    // ✨ Fungsi Getter & Setter untuk nama dan kitaran yang dicari oleh AuthServlet
    public String getName() { return name; }
    public void   setName(String name) { this.name = name; }

    public int    getCycleLength() { return cycleLength; }
    public void   setCycleLength(int cycleLength) { this.cycleLength = cycleLength; }
}